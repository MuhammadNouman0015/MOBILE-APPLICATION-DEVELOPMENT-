package com.quizer911.quizer911

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
